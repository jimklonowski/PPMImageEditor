﻿module PPMImageLibrary

#light


//
// DebugOutput:
//
// Outputs to console, which appears in the "Output" window pane of
// Visual Studio when you run with debugging (F5).
//
let rec private OutputImage(image:int list list) = 
  if image = [] then
    printfn "**END**"
  else
    printfn "%A" image.Head
    OutputImage(image.Tail)
           
let DebugOutput(width:int, height:int, depth:int, image:int list list) =
  printfn "**HEADER**"
  printfn "W=%A, H=%A, D=%A" width height depth
  printfn "**IMAGE**"
  OutputImage(image)


//
// TransformFirstRowWhite:
//
// An example transformation: replaces the first row of the given image
// with a row of all white pixels.
//
let rec BuildRowOfWhite cols white = 
  if cols = 0 then
    []
  else 
    // 1 pixel, i.e. RGB value, followed by remaining pixels:
    white :: white :: white :: BuildRowOfWhite (cols-1) white

let TransformFirstRowWhite(width:int, height:int, depth:int, image:int list list) = 
  // first row all white :: followed by rest of original image
  BuildRowOfWhite width depth :: image.Tail


//
// WriteP3Image:
//
// Writes the given image out to a text file, in "P3" format.  Returns true if successful,
// false if not.
//
let rec WriteP3Image(filepath:string, width:int, height:int, depth:int, image:int list list) = 
  //
  // Here's one possible strategy: build a list of strings, then WriteAllLines.
  // Each string appears on a separate line. 
  //
  let L = ["Hello"; "World"; "1 2 3"; "10 20 30"]
  System.IO.File.WriteAllLines(filepath, L)
  //
  true  // success



let rec TransformGrayscale(width:int, height:int, depth:int, image:int list list) = 
  image



let rec TransformInvert(width:int, height:int, depth:int, image:int list list) = 
  image



let rec TransformFlipHorizontal(width:int, height:int, depth:int, image:int list list) = 
  image



let rec TransformFlipVertical(width:int, height:int, depth:int, image:int list list) = 
  image



let rec RotateRight90(width:int, height:int, depth:int, image:int list list) = 
  image